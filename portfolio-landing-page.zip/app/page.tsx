const projects = [
  {
    number: '01',
    title: 'Nusantara House',
    category: 'Brand identity · Digital',
    year: '2024',
    className: 'project-visual project-visual--house',
  },
  {
    number: '02',
    title: 'Form / Function',
    category: 'Art direction · Editorial',
    year: '2023',
    className: 'project-visual project-visual--form',
  },
  {
    number: '03',
    title: 'Quiet Objects',
    category: 'Strategy · E-commerce',
    year: '2023',
    className: 'project-visual project-visual--objects',
  },
]

const principles = [
  ['01', 'Clarity first', 'Ide yang kuat tidak perlu berteriak. Kami menyederhanakan sampai yang tersisa benar-benar penting.'],
  ['02', 'Details matter', 'Setiap jarak, kata, dan transisi memiliki peran dalam membangun pengalaman yang terasa tepat.'],
  ['03', 'Built to last', 'Membuat sistem yang fleksibel, bukan sekadar tampilan yang terlihat baik hari ini.'],
]

export default function Page() {
  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Kembali ke atas">AR / STUDIO</a>
        <nav className="desktop-nav" aria-label="Navigasi utama">
          <a href="#work">Work</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </nav>
        <a className="header-link" href="mailto:hello@yourname.studio">Let&apos;s talk <span aria-hidden="true">↗</span></a>
      </header>

      <section id="top" className="hero section-shell">
        <div className="hero-kicker"><span className="status-dot" aria-hidden="true" /> Independent creative studio · Jakarta / Worldwide</div>
        <h1>Ideas with<br /><em>intention.</em></h1>
        <div className="hero-bottom">
          <p className="hero-intro">Kami membantu brand dan bisnis membangun identitas yang jelas, relevan, dan bertahan lama.</p>
          <div className="hero-actions">
            <a className="button button-dark" href="#work">Lihat pilihan karya <span aria-hidden="true">↓</span></a>
            <a className="text-link" href="#about">Tentang studio <span aria-hidden="true">↗</span></a>
          </div>
          <div className="availability"><span>Available for select projects</span><strong>2025 — 2026</strong></div>
        </div>
      </section>

      <section id="work" className="work-section section-shell">
        <div className="section-heading"><p className="eyebrow">Selected work</p><p className="section-note">A small selection of recent collaborations</p></div>
        <div className="project-list">
          {projects.map((project) => (
            <article className="project" key={project.number}>
              <div className={project.className} aria-hidden="true"><span>{project.number}</span><i /></div>
              <div className="project-meta"><span className="project-number">{project.number}</span><div><h2>{project.title}</h2><p>{project.category}</p></div><span className="project-year">{project.year}</span><span className="project-arrow" aria-hidden="true">↗</span></div>
            </article>
          ))}
        </div>
      </section>

      <section id="about" className="about-section section-shell">
        <div className="section-heading"><p className="eyebrow">About</p><p className="section-note">Small team, considered work</p></div>
        <div className="about-grid"><h2>We make thoughtful<br /><em>things matter.</em></h2><div className="about-copy"><p>AR / Studio adalah partner kreatif untuk brand yang ingin bergerak dengan lebih terarah. Dari strategi hingga eksekusi, kami menemukan bentuk paling jujur untuk sebuah ide.</p><p>Bekerja lintas identitas, digital, dan editorial dengan pendekatan yang tenang, teliti, dan kolaboratif.</p></div></div>
        <div className="principles">{principles.map(([number, title, copy]) => <div className="principle" key={number}><span>{number}</span><h3>{title}</h3><p>{copy}</p></div>)}</div>
      </section>

      <section id="contact" className="contact-section section-shell"><p className="eyebrow">Have a project in mind?</p><h2>Let&apos;s make<br /><em>something clear.</em></h2><a className="contact-email" href="mailto:hello@yourname.studio">hello@yourname.studio <span aria-hidden="true">↗</span></a></section>

      <footer className="site-footer"><span>© 2025 AR / Studio</span><div><a href="#top">Instagram</a><a href="#top">LinkedIn</a><a href="#top">Back to top ↑</a></div></footer>
    </main>
  )
}
export { projects, principles }
